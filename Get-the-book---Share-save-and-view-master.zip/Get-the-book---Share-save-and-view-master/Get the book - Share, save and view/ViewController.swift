//
//  ViewController.swift
//  Get the book - Share, save and view
//
//  Created by Hemanth Kasoju on 2018-11-12.
//  Copyright © 2018 Hemanth Kasoju. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

